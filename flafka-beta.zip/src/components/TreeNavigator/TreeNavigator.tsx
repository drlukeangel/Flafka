import React, { useEffect, useState } from 'react';
import { useWorkspaceStore } from '../../store/workspaceStore';
import { TreeNode as TreeNodeType } from '../../types';
import { insertTextAtCursor } from '../EditorCell/editorRegistry';
import {
  FiChevronRight,
  FiChevronDown,
  FiDatabase,
  FiFolder,
  FiGrid,
  FiEye,
  FiBox,
  FiCode,
  FiExternalLink,
  FiLoader,
  FiSearch,
  FiX,
  FiCopy,
  FiRefreshCw,
} from 'react-icons/fi';

/**
 * Escape special regex characters in a user-supplied string.
 */
function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Quote SQL identifiers if they contain non-alphanumeric chars or start with digit.
 */
function quoteIdentifierIfNeeded(name: string): string {
  if (/[^a-zA-Z0-9_]/.test(name) || /^[0-9]/.test(name)) {
    return `\`${name}\``;
  }
  return name;
}

/**
 * Recursively filter tree nodes by name query.
 * - If query is empty, return nodes unchanged.
 * - A node is kept if its name matches OR if any descendant matches.
 * - When a parent is kept due to matching children, those children are returned
 *   expanded so the matches are immediately visible.
 */
function filterTree(nodes: TreeNodeType[], query: string): TreeNodeType[] {
  if (!query.trim()) return nodes;

  const lower = query.toLowerCase();

  return nodes.reduce<TreeNodeType[]>((acc, node) => {
    const nameMatches = node.name.toLowerCase().includes(lower);

    if (node.children && node.children.length > 0) {
      const filteredChildren = filterTree(node.children, query);
      if (nameMatches || filteredChildren.length > 0) {
        // Keep parent, show filtered children expanded so matches are visible
        acc.push({
          ...node,
          isExpanded: filteredChildren.length > 0 ? true : node.isExpanded,
          children: filteredChildren.length > 0 ? filteredChildren : node.children,
        });
      }
    } else {
      if (nameMatches) {
        acc.push(node);
      }
    }

    return acc;
  }, []);
}

/**
 * Render a node label with the matching portion highlighted.
 */
function HighlightedLabel({ name, query }: { name: string; query: string }) {
  if (!query.trim()) {
    return <span className="node-label">{name}</span>;
  }

  const regex = new RegExp(`(${escapeRegex(query)})`, 'gi');
  const parts = name.split(regex);

  return (
    <span className="node-label">
      {parts.map((part, i) =>
        regex.test(part) ? (
          <span key={i} className="tree-highlight">{part}</span>
        ) : (
          part
        )
      )}
    </span>
  );
}

const TreeNavigator: React.FC = () => {
  const {
    treeNodes,
    treeLoading,
    selectedNodeId,
    loadTreeData,
    toggleTreeNode,
    selectTreeNode,
    addStatement,
    catalog,
    database,
    selectedTableSchema,
    selectedTableName,
    schemaLoading,
    addToast,
    loadTableSchema,
  } = useWorkspaceStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [copiedColName, setCopiedColName] = useState<string | null>(null);

  const handleSchemaColumnClick = async (columnName: string) => {
    const quoted = quoteIdentifierIfNeeded(columnName);
    try {
      await navigator.clipboard.writeText(quoted);
      addToast({ type: 'success', message: `Copied: ${columnName}` });
      setCopiedColName(columnName);
      setTimeout(() => setCopiedColName(null), 600);
    } catch {
      addToast({ type: 'error', message: 'Failed to copy' });
    }
  };

  const handleSchemaColumnDoubleClick = (columnName: string) => {
    const quoted = quoteIdentifierIfNeeded(columnName);
    const inserted = insertTextAtCursor(quoted);
    if (inserted) {
      addToast({ type: 'success', message: `Inserted: ${columnName}` });
    } else {
      addToast({ type: 'warning', message: 'No active editor. Click an editor first.' });
    }
  };

  const handleSchemaRefresh = () => {
    if (selectedTableName) {
      loadTableSchema(catalog, database, selectedTableName);
    }
  };

  useEffect(() => {
    loadTreeData();
  }, [loadTreeData]);

  const handleDoubleClick = (node: TreeNodeType) => {
    if (node.type === 'table' || node.type === 'view') {
      const tableName = node.name;
      const query = `SELECT * FROM \`${catalog}\`.\`${database}\`.\`${tableName}\` LIMIT 10;`;
      addStatement(query);
    }
  };

  const displayedNodes = filterTree(treeNodes, searchQuery);
  const isFiltering = searchQuery.trim().length > 0;

  return (
    <div className="tree-navigator">
      <div className="tree-header">
        <h3>Workspace Explorer</h3>
      </div>
      <div className="tree-search">
        <FiSearch size={14} className="tree-search-icon" />
        <input
          className="tree-search-input"
          type="text"
          placeholder="Filter objects..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          aria-label="Filter tree objects"
        />
        {searchQuery && (
          <button
            className="tree-search-clear"
            onClick={() => setSearchQuery('')}
            aria-label="Clear filter"
          >
            <FiX size={12} />
          </button>
        )}
      </div>
      <div className="tree-content">
        {treeLoading ? (
          <div className="tree-loading">
            <FiLoader className="animate-spin" />
            <span>Loading...</span>
          </div>
        ) : displayedNodes.length > 0 ? (
          displayedNodes.map((node) => (
            <TreeNodeComponent
              key={node.id}
              node={node}
              level={0}
              selectedNodeId={selectedNodeId}
              onToggle={toggleTreeNode}
              onSelect={selectTreeNode}
              onDoubleClick={handleDoubleClick}
              searchQuery={searchQuery}
              addToast={addToast}
            />
          ))
        ) : isFiltering ? (
          <div className="tree-empty">
            <span>No results for &ldquo;{searchQuery}&rdquo;</span>
          </div>
        ) : (
          <div className="tree-empty">
            <span>No database objects found</span>
          </div>
        )}
      </div>
      {selectedTableName && (
        <div className="schema-panel" role="region" aria-label="Table schema">
          <div className="schema-header">
            <h4>{selectedTableName}</h4>
            <button
              className={`schema-refresh-btn ${schemaLoading ? 'loading' : ''}`}
              onClick={handleSchemaRefresh}
              disabled={schemaLoading}
              title="Refresh schema"
              aria-label="Refresh schema"
            >
              <FiRefreshCw size={14} />
            </button>
          </div>
          {schemaLoading ? (
            <div className="schema-loading"><FiLoader className="animate-spin" /> Loading...</div>
          ) : selectedTableSchema.length > 0 ? (
            <div className="schema-content">
              <div className="schema-section">
                <span className="schema-section-title">Schema ({selectedTableSchema.length})</span>
              </div>
              {selectedTableSchema.map((col) => (
                <div
                  key={col.name}
                  className={`schema-column${copiedColName === col.name ? ' schema-column--copied' : ''}`}
                  onClick={() => handleSchemaColumnClick(col.name)}
                  onDoubleClick={(e) => { e.preventDefault(); handleSchemaColumnDoubleClick(col.name); }}
                  title="Single-click to copy, double-click to insert at cursor"
                >
                  <span className="column-name">{col.name}</span>
                  <span className="column-type">{col.type}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="schema-empty">No columns found</div>
          )}
        </div>
      )}
    </div>
  );
};

/**
 * Check if a node type is a category node that should display a count badge.
 */
function isCategoryNode(nodeType: string): boolean {
  return ['tables', 'views', 'models', 'functions', 'externalTables'].includes(nodeType);
}

interface TreeNodeProps {
  node: TreeNodeType;
  level: number;
  selectedNodeId: string | null;
  onToggle: (nodeId: string) => void;
  onSelect: (nodeId: string) => void;
  onDoubleClick: (node: TreeNodeType) => void;
  searchQuery: string;
  addToast: (toast: { type: 'success' | 'error' | 'info' | 'warning'; message: string }) => void;
}

const TreeNodeComponent: React.FC<TreeNodeProps> = ({
  node,
  level,
  selectedNodeId,
  onToggle,
  onSelect,
  onDoubleClick,
  searchQuery,
  addToast,
}) => {
  const hasChildren = node.children && node.children.length > 0;
  const isExpandable = hasChildren || ['catalog', 'database', 'tables', 'views', 'models', 'functions', 'externalTables'].includes(node.type);
  const isSelected = selectedNodeId === node.id;
  const isEmpty = node.children?.length === 0 && ['tables', 'views', 'models', 'functions', 'externalTables'].includes(node.type);

  const getIcon = () => {
    switch (node.type) {
      case 'catalog':
        return <FiFolder className="node-icon catalog" />;
      case 'database':
        return <FiDatabase className="node-icon database" />;
      case 'tables':
      case 'table':
        return <FiGrid className="node-icon table" />;
      case 'views':
      case 'view':
        return <FiEye className="node-icon view" />;
      case 'models':
      case 'model':
        return <FiBox className="node-icon model" />;
      case 'functions':
      case 'function':
        return <FiCode className="node-icon function" />;
      case 'externalTables':
      case 'externalTable':
        return <FiExternalLink className="node-icon external" />;
      default:
        return <FiFolder className="node-icon" />;
    }
  };

  const isCopyableNode = node.type === 'table' || node.type === 'view' || node.type === 'externalTable';

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelect(node.id);
    if (isExpandable) {
      onToggle(node.id);
    }
  };

  const handleDoubleClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onDoubleClick(node);
  };

  const handleTableCopyClick = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const quoted = quoteIdentifierIfNeeded(node.name);
    try {
      await navigator.clipboard.writeText(quoted);
      addToast({ type: 'success', message: `Copied: ${node.name}` });
    } catch {
      addToast({ type: 'error', message: 'Failed to copy' });
    }
  };

  return (
    <div className="tree-node-wrapper">
      <div
        className={`tree-node ${isSelected ? 'selected' : ''}`}
        style={{ paddingLeft: `${level * 16 + 4}px` }}
        onClick={handleClick}
        onDoubleClick={handleDoubleClick}
      >
        <span className="node-chevron">
          {isExpandable ? (
            node.isExpanded ? (
              <FiChevronDown size={14} />
            ) : (
              <FiChevronRight size={14} />
            )
          ) : (
            <span style={{ width: 14 }} />
          )}
        </span>
        {getIcon()}
        <HighlightedLabel name={node.name} query={searchQuery} />
        {isCategoryNode(node.type) && (
          <span className={`tree-node-badge${(node.children?.length || 0) === 0 ? ' tree-node-badge--empty' : ''}`}>
            {node.children?.length || 0}
          </span>
        )}
        {node.isLoading && <FiLoader className="animate-spin node-loading" size={12} />}
        {isCopyableNode && (
          <span
            className="tree-node-copy-icon"
            onClick={handleTableCopyClick}
            title={`Copy: ${quoteIdentifierIfNeeded(node.name)}`}
            aria-label={`Copy table name ${node.name}`}
          >
            <FiCopy size={12} />
          </span>
        )}
      </div>

      {node.isExpanded && hasChildren && (
        <div className="tree-children">
          {node.children!.map((child) => (
            <TreeNodeComponent
              key={child.id}
              node={child}
              level={level + 1}
              selectedNodeId={selectedNodeId}
              onToggle={onToggle}
              onSelect={onSelect}
              onDoubleClick={onDoubleClick}
              searchQuery={searchQuery}
              addToast={addToast}
            />
          ))}
        </div>
      )}

      {node.isExpanded && isEmpty && (
        <div
          className="tree-empty-category"
          style={{ paddingLeft: `${(level + 1) * 16 + 4}px` }}
        >
          <span className="empty-text">No {node.name.toLowerCase()} yet</span>
        </div>
      )}
    </div>
  );
};

export default TreeNavigator;
