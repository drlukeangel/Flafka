"""TableFunction that explodes a JSON array into one row per element.

Each emitted row contains:
  - array_index (INT): zero-based position in the array
  - element_json (STRING): JSON string of the array element

Designed to chain with loan_detail_extract for full extraction pipelines:
  SELECT t.f0, loan_detail_extract(t.f1, 'lender') AS lender
  FROM loans, LATERAL TABLE(loan_detail_explode(json_col, 'bureau_data.tradelines')) AS t

Qualified name for CREATE FUNCTION:
  loan_detail_udf.exploder.loan_detail_explode
"""

from __future__ import annotations

import json
from typing import Iterator

from pyflink.table import DataTypes
from pyflink.table.types import DataType
from pyflink.table.udf import udtf

from loan_detail_udf.extractor import _traverse_path


def _explode(json_str: str, array_path: str) -> Iterator[tuple[int, str]]:
    """Explode a JSON array into (index, element_json) rows."""
    if not json_str or not array_path:
        return
    try:
        root = json.loads(json_str)
        node = _traverse_path(root, array_path)
        if not isinstance(node, list):
            return
        for i, element in enumerate(node):
            if isinstance(element, (dict, list)):
                yield i, json.dumps(element)
            else:
                yield i, str(element)
    except Exception:
        return


_explode_input_types: list[DataType] = [DataTypes.STRING(), DataTypes.STRING()]
loan_detail_explode = udtf(
    _explode,
    input_types=_explode_input_types,
    result_types=[DataTypes.INT(), DataTypes.STRING()],
)
