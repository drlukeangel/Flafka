"""ScalarFunction that extracts values from deeply nested JSON using dot-notation paths.

Supports:
  - Nested object traversal: "underwriting.risk_assessment.credit_analysis.bureau_data.score"
  - Array index access: "collateral.items[0].valuation.appraised_value"
  - Returns None on missing paths or malformed JSON (safe for SQL)
  - Returns JSON string for object/array nodes

Qualified name for CREATE FUNCTION:
  loan_detail_udf.extractor.loan_detail_extract
"""

from __future__ import annotations

import json
import re
from typing import Any

from pyflink.table import DataTypes
from pyflink.table.types import DataType
from pyflink.table.udf import udf

ARRAY_PATTERN = re.compile(r"^(.+?)\[(\d+)]$")


def _traverse_path(root: Any, path: str) -> Any:
    """Traverse a JSON object using a dot-notation path with optional array indices.

    Shared by both extractor and exploder to avoid code duplication
    (mirrors LoanDetailExtractor.traversePath in Java).
    """
    node = root
    for segment in path.split("."):
        if node is None:
            return None
        m = ARRAY_PATTERN.match(segment)
        if m:
            field, index = m.group(1), int(m.group(2))
            node = node.get(field) if isinstance(node, dict) else None
            if not isinstance(node, list) or index >= len(node):
                return None
            node = node[index]
        else:
            node = node.get(segment) if isinstance(node, dict) else None
    return node


def _extract(json_str: str, path: str) -> str | None:
    """Extract a value from nested JSON using dot-notation path."""
    if not json_str or not path:
        return None
    try:
        root = json.loads(json_str)
        node = _traverse_path(root, path)
        if node is None:
            return None
        if isinstance(node, (dict, list)):
            return json.dumps(node)
        return str(node)
    except Exception:
        return None


_extract_input_types: list[DataType] = [DataTypes.STRING(), DataTypes.STRING()]
loan_detail_extract = udf(
    _extract,
    input_types=_extract_input_types,
    result_type=DataTypes.STRING(),
)
